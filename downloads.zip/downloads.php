<?php
 include('includes/html_header.php');
 ?>
 <?php
 include('includes/navbar.php');
 ?>

<section id="breadcrumb">
         <div class="bg-overlay pt-opacity4" style="background-image: url('img/hero_12.jpg');"></div>
         <div class="container">
            <div class="row">
               <div class="col-sm-12">
                  <h2 class="breadcrumb-title">Download Reports</h2>
                  <nav aria-label="breadcrumb">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Download Reports</li>
                     </ol>
                  </nav>
               </div>
            </div>
         </div>
</section>

<!--download items  -->
<section id="download_reports">
    <div class="container">
         <div class="row">
             <h2 class="section-title"> Documents</h2>
             <div class="col-lg-3">
                 <a href="img/downloads/mep.jpeg" target="_blank" download>
                    <div class="card">
                        <div class="card-body">
                           <h5 class="heading_title"> MEP E-Bid Invitation</h5>
                           <img src="img/icon-document.svg" class="download_icon" alt="">
                        </div>
                    </div>
                 </a>
             </div>
             <div class="col-lg-3">
                 <a href="img/downloads/MEP-Technical-Specifcation-Upper-Station.doc" target="_blank" download>
                    <div class="card">
                         <div class="card-body">
                             <h5 class="heading_title"> MEPBIDDOC Technical SPecification</h5>
                             <img src="img/icon-document.svg" class="download_icon" alt="">
                         </div>
                    </div>
                 </a>
             </div>
             <div class="col-lg-3">
                  <a href="img/downloads/BOQ-of-MEP-Upper-Station.xlsx" target="_blank" download>
                     <div class="card">
                         <div class="card-body">
                            <h5 class="heading_title">BOQ of MEP Upper Station</h5>
                            <img src="img/icon-document.svg" class="download_icon" alt="">
                         </div>
                     </div>
                  </a>
             </div>
             <div class="col-lg-3">
                 <a href="https://drive.google.com/file/d/1joXT4TeUL9U1xDF5_6hNfC9Y9Uqfd6rl/view" target="_blank" download>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="heading_title">MEP Bidding Document</h5>
                            <img src="img/icon-document.svg" class="download_icon" alt="">
                        </div>
                    </div>
                 </a>
             </div>
         </div>
         <!--row end  -->
         <!-- other document download row -->
         <div class="download-two"> 
              <div class="row">
                 <div class="col-lg-3">
                     <a target="_blank" href="https://drive.google.com/file/d/13YzhLfhcQVct_JsWcxRECo13J1Tluy6y/view" title=" Report" download>
                       <div class="card">
                            <div class="card-body">
                               <h5 class="heading_title">Bandipur Cable Car Share Form</h5>
                               <img src="img/icon-document.svg" class="download_icon" alt="">
                            </div>
                       </div>
                     </a>
                 </div>
                 <div class="col-lg-3">
                     <a target="_blank" href="img/reports/bandipur book 2078 Final pdf" target="_blank" title=" Report" download> 
                         <div class="card">
                            <div class="card-body">
                                <h5 class="heading_title"> Bandipur Cable Car 7th Annual General Meeting 2077/78(2078/06/21)</h5>
                                <img src="img/icon-document.svg" class="download_icon" alt="">
                            </div>
                         </div>
                     </a>
                 </div>
                 <div class="col-lg-3">
                     <a target="_blank" href="https://drive.google.com/file/d/1WbEX4ftOlxHlAZ_KGZe3Yvxd73WKzmIK/view" title="Audit Report" download>
                        <div class="card">
                             <div class="card-body">
                                <h5 class="heading_title">Bandipur Cable Car 5th Annual  2075/76( 2076-10-25)</h5>
                                <img src="img/icon-document.svg" class="download_icon" alt="">               
                             </div>
                        </div>
                     </a>   
                 </div>
                
              </div>
              <!-- row end -->
         </div>
         <!-- download-two end -->
         <div class="row care_rating mt-5"> 
             <h2 class="section-title">CARE Ratings</h2>            
         <div class="col-lg-3">
                     <a target="_blank" href="https://careratingsnepal.com/wp-content/uploads/2021/04/Bandipur-Cable-Car-Private-Limited-Ratings-Assigned-to-the-Bank-Facilities.pdf" title=" Report" download>
                       <div class="card">
                            <div class="card-body">
                               <h5 class="heading_title">CARE-NP BB</h5>
                               <img src="img/icon-document.svg" class="download_icon" alt="">
                            </div>
                       </div>
                     </a>
                 </div>
         </div>
        
          <!-- care_rating end -->
        
          <div class="row  mt-5"> 
             <h2 class="section-title">Project Flow</h2>            
         <div class="col-lg-3">
                     <a target="_blank" href="img/reports/graph_talika.pdf" title=" Report" download>
                       <div class="card">
                            <div class="card-body">
                                  <h5 class="heading_title">Work Schedule Of Bandipur Cablecar Project</h5>
                               <img src="img/icon-document.svg" class="download_icon" alt="">
                            </div>
                       </div>
                     </a>
                 </div>
                 <div class="col-lg-3">
                     <a target="_blank" href="img/reports/work_talika.pdf" title=" Report" download> 
                         <div class="card">
                            <div class="card-body">
                                <h5 class="heading_title">Work Schedule</h5>
                                <img src="img/icon-document.svg" class="download_icon" alt="">
                            </div>
                         </div>
                     </a>
                 </div>                    
         </div>
    </div>
</section>

<?php
 include('includes/footer.php');
 ?>